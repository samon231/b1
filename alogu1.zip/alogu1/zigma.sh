#!/bin/bash

./alooge --address='NQ57 CSJB 0RH1 V2DV 4784 2M19 41H3 65X3 4S2E' --threads=10 --server=eu1-nim.coinhunters.name --port=8544
